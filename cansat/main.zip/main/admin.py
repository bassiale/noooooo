from django.contrib import admin
from .models import bmp_data

admin.site.register(bmp_data)
# Register your models here.
